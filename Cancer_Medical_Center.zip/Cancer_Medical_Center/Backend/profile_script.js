function show_course() {
	document.getElementById("apDiv8").style.visibility = "visible";
}
function hide_course() {
	document.getElementById("apDiv8").style.visibility = "hidden";
}
function show() {
	document.getElementById("apDiv9").style.visibility = "visible";
}
function hide() {
	document.getElementById("apDiv9").style.visibility = "hidden";
}
function show1() {
	document.getElementById("apDiv10").style.visibility = "visible";
}
function hide1() {
	document.getElementById("apDiv10").style.visibility = "hidden";
}
function show2() {
	document.getElementById("apDiv11").style.visibility = "visible";
}
function hide2() {
	document.getElementById("apDiv11").style.visibility = "hidden";
}
function show3() {
	document.getElementById("apDiv13").style.visibility = "visible";
}
function hide3() {
	document.getElementById("apDiv13").style.visibility = "hidden";
}